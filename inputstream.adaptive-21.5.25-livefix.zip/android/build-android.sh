#!/bin/bash
# Builds inputstream.adaptive for Android (armeabi-v7a by default) and zips it.
set -euo pipefail
ABI="${ABI:-armeabi-v7a}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"
W="$SRC/_work"
rm -rf "$W" && mkdir -p "$W"
NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_ROOT:-${ANDROID_NDK_HOME:-}}}"
[ -n "$NDK" ] || { echo "NDK not found"; exit 1; }
TC="$NDK/build/cmake/android.toolchain.cmake"
COMMON=(-DCMAKE_TOOLCHAIN_FILE="$TC" -DANDROID_ABI="$ABI" -DANDROID_PLATFORM=android-21
        -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release -DCMAKE_POSITION_INDEPENDENT_CODE=ON
        -DCMAKE_POLICY_VERSION_MINIMUM=3.5)
DEPS="$W/deps"

echo "== Kodi dev kit"
git clone -q --depth 1 --filter=blob:none --sparse --branch Omega https://github.com/xbmc/xbmc.git "$W/xbmc"
git -C "$W/xbmc" sparse-checkout set xbmc/addons/kodi-dev-kit
KODI_DEVKIT_DIR="$W/xbmc/xbmc/addons/kodi-dev-kit"

echo "== pugixml"
git clone -q --depth 1 --branch v1.13 https://github.com/zeux/pugixml.git "$W/pugixml"
cmake -S "$W/pugixml" -B "$W/pugixml/b" "${COMMON[@]}" -DCMAKE_INSTALL_PREFIX="$DEPS" -DBUILD_SHARED_LIBS=OFF
cmake --build "$W/pugixml/b" -j && cmake --install "$W/pugixml/b"

echo "== rapidjson"
git clone -q "https://github.com/Tencent/rapidjson.git" "$W/rapidjson"
git -C "$W/rapidjson" checkout -q 5ec44fb9206695e5293f610b0a46d21851d0c966
mkdir -p "$DEPS/include" && cp -r "$W/rapidjson/include/rapidjson" "$DEPS/include/"

echo "== Bento4"
git clone -q --depth 1 --branch 1.6.0-641-3-Omega https://github.com/xbmc/Bento4.git "$W/bento4"
for p in $(ls "$SRC"/depends/common/bento4/*.patch 2>/dev/null | sort); do
  echo "patch $p"; (cd "$W/bento4" && patch -p1 -i "$p")
done
cmake -S "$W/bento4" -B "$W/bento4/b" "${COMMON[@]}" -DCMAKE_INSTALL_PREFIX="$DEPS" \
      -DCMAKE_INSTALL_INCLUDEDIR=include -DCMAKE_INSTALL_LIBDIR=lib -DBUILD_APPS=OFF
cmake --build "$W/bento4/b" -j && cmake --install "$W/bento4/b"
ls "$DEPS/include" "$DEPS/lib"

echo "== inputstream.adaptive"
cmake -S "$SRC" -B "$W/isa" "${COMMON[@]}" \
  -DCMAKE_INSTALL_PREFIX="$W/out" -DCMAKE_PREFIX_PATH="$DEPS" -DCMAKE_FIND_ROOT_PATH="$DEPS" \
  -DKodi_DIR="$SRC/android/shim" -DKODI_DEVKIT_DIR="$KODI_DEVKIT_DIR" \
  -DENABLE_INTERNAL_BENTO4=OFF -DBUILD_TESTING=OFF -DOVERRIDE_PATHS=1 \
  -DPUGIXML_INCLUDE_DIRS="$DEPS/include" -DPUGIXML_LIBRARIES="$DEPS/lib/libpugixml.a" \
  -DBENTO4_INCLUDE_DIR="$DEPS/include" -DBENTO4_LIBRARY="$DEPS/lib/libap4.a" \
  -DRAPIDJSON_INCLUDES="$DEPS/include"
cmake --build "$W/isa" -j
cmake --install "$W/isa"

echo "== package"
PKG="$W/pkg/inputstream.adaptive"
mkdir -p "$PKG"
cp -r "$W/out/share/kodi/addons/inputstream.adaptive/." "$PKG/"
cp "$W/out/lib/kodi/addons/inputstream.adaptive/"*.so "$PKG/"
find "$W/out" -type f | head -50
( cd "$W/pkg" && zip -qr "$SRC/inputstream.adaptive-21.5.99-android-$ABI.zip" inputstream.adaptive )
echo done
