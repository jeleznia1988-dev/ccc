#.rst:
# FindGtest
# --------
# Finds the gtest library
#
# This will define the following variables::
#
# GTEST_FOUND - system has gtest
# GTEST_INCLUDE_DIRS - the gtest include directories
# GTEST_LIBRARIES - the gtest libraries
#
# and the following imported targets:
#
#   Gtest::Gtest   - The gtest library


if(PKG_CONFIG_FOUND)
  pkg_check_modules(PC_GTEST gtest>=1.10.0 QUIET)
  set(GTEST_VERSION ${PC_GTEST_VERSION})
elseif(WIN32)
  set(GTEST_VERSION 1.10.0)
endif()

find_path(GTEST_INCLUDE_DIR NAMES gtest/gtest.h
                            PATHS ${PC_GTEST_INCLUDEDIR})

find_library(GTEST_LIBRARY_RELEASE NAMES gtest
                                   PATHS ${PC_GTEST_LIBDIR})
find_library(GTEST_LIBRARY_DEBUG NAMES gtestd
                                 PATHS ${PC_GTEST_LIBDIR})

include(SelectLibraryConfigurations)
select_library_configurations(GTEST)

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(Gtest
                                  REQUIRED_VARS GTEST_LIBRARY GTEST_INCLUDE_DIR
                                  VERSION_VAR GTEST_VERSION)

if(GTEST_FOUND)
  set(GTEST_LIBRARIES ${GTEST_LIBRARY})
  set(GTEST_INCLUDE_DIRS ${GTEST_INCLUDE_DIR})
endif()

if(NOT TARGET Gtest::Gtest)
  add_library(Gtest::Gtest UNKNOWN IMPORTED)
  set_target_properties(Gtest::Gtest PROPERTIES
                                     IMPORTED_LOCATION "${GTEST_LIBRARY}"
                                     INTERFACE_INCLUDE_DIRECTORIES "${GTEST_INCLUDE_DIR}")
endif()

mark_as_advanced(GTEST_INCLUDE_DIR GTEST_LIBRARY)
